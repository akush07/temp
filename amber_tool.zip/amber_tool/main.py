

from utils.loggers import logger, session


import os
import warnings
import logging
from datetime import datetime
from utils.configs import LoadConfig
from models.text_modelling import TextModel

logger = logging.getLogger(__name__)
stream = logging.StreamHandler()
logger.addHandler(stream)

def main():
    start = datetime.now()
    cfg = LoadConfig()
    config = cfg.config
    output_dir = os.path.join(config.get('general_settings',{}).get('outputdir', 'outputs'), session) 
    text_col = cfg.config.get('text_col')
    input_filepath = cfg.config.get('input_filepath')
    if not input_filepath:
        raise FileNotFoundError('input filepath not found..')
    
    tm = TextModel(session)
    tm.load_config(os.environ.get('CONFIG_PATH'))
    tm.load_data(input_filepath)
    tm.set_output_dir()
    tm.transform()
    
    
    tm_neg = TextModel(session)
    tm_neg.load_config(os.environ.get('CONFIG_PATH'))
    
    
    def _run_function(function_name, text_col, clustering_col, topicmodel_objs):
        if text_col:
            transform_flag = False
            if not text_col==topicmodel_objs.text_col:
                transform_flag = True
                topicmodel_objs.text_col = text_col
            if transform_flag:
                topicmodel_objs.transform()
        clustering_col = [col for col in clustering_col if col is not None]
        
        if function_name=='sentiment':
            logger.info('starting function: {}'.format(function_name))
            topicmodel_objs.get_sentiment(save_sentiment_file=True)
        elif function_name=='wordcloud':
            logger.info('starting function: {}'.format(function_name))
            topicmodel_objs.get_wordcloud(clustering_col)
        elif function_name=='summary':
            logger.info('starting function: {}'.format(function_name))
            topicmodel_objs.get_summaries(clustering_col)
        else:
            raise ValueError(f"incorrect function name passed {function_name}")
        
    
    for observation, params in config.get('observations',{}).items():
        neg_sentiment_only = params.get('neg_sentiment_only', False)
        functionalities = params.get('functionality',[])
        text_col = params.get('text_col',None)
        clustering_col = params.get('clustering_cols',[])
        enable = params.get('enable', True)                
        if not neg_sentiment_only:            
            if enable:
                logger.info('starting for {}'.format(observation))
                tm.set_output_dir(output_dir_path=os.path.join(output_dir, str(observation)))
                for function in functionalities:                  
                    _run_function(function, text_col, clustering_col, tm)
        else:
            if tm.get_sentiment_data().empty:
                tm = tm.get_sentiment()
            data_with_sentiment = tm.get_sentiment_data()
            df_neg_sentiment =  data_with_sentiment[data_with_sentiment['final sentiment score']<=0]
            tm_neg.set_raw_data(df_neg_sentiment)
            tm_neg.set_sentiment_data(df_neg_sentiment)
            tm_neg.text_col = text_col
            tm_neg.transform()            
            if enable:
                logger.info('starting for {}'.format(observation))
                tm_neg.set_output_dir(output_dir_path=os.path.join(output_dir, str(observation)))
                for function in functionalities:                  
                    _run_function(function, text_col, clustering_col, tm_neg)


    end = datetime.now()
    logger.info(f"process ended in {end - start}")
    

if __name__=='__main__':
    main()