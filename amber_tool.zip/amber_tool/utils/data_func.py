# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 23:29:32 2021

@author: Akush
"""


import os
import pandas as pd
from typing import TypeVar
from utils.exceptions import FileError



Dataframe = TypeVar("pandas.core.dataframe.DataFrame")


def read_data(filepath: str) -> Dataframe:
    """
    This function reads data automatically depending on the type of file
    """
    if not isinstance(filepath, str):
        raise AttributeError("filepath not in string format.")
    extension = filepath.rsplit(".", 1)[-1]
    data = pd.DataFrame()
    
    try:
        if extension=='csv':
            try:
                data = pd.read_csv(filepath)
            except:
                data = pd.read_csv(filepath, encoding='utf-8')
                
        elif extension=='xlsx':
            data = pd.read_excel(filepath)
        
        else:
            raise FileError("Unable to read data, unknown file format")
        return data
        
    except Exception as e:
        raise e