# -*- coding: utf-8 -*-
"""
Created on Wed Jul 21 20:52:09 2021

@author: Akush
"""



import numpy as np
import pandas as pd
from itertools import permutations


def odds_ratio(p):
    try:
        odd = p/(1-p)
    except ZeroDivisionError:
        odd = np.inf
    return odd


def analyze_data(data, grouping_cols, target_col):
    df = data.copy()
    df_analysis = df.groupby(grouping_cols)[target_col].apply(pd.value_counts).fillna(0).T
    df_analysis = pd.DataFrame(df_analysis.unstack())
    df_analysis = pd.Index(list(df_analysis.columns))
    
    #for laplace smoothening
    df_analysis = df_analysis.replace(0,1)
    df_analysis.loc[:,'total_sample'] = df_analysis.sum(axis=1)
    
    for col in df_analysis.columns:
        if not col == 'total_sample':
            df_analysis['prob_'+str(col)] = df_analysis[col]/df_analysis['total_sample']
            df_analysis['odds_'+str(col)] = df_analysis['prob_'+str(col)].apply(odds_ratio)
    
    list_of_odd_cols = [col for col in list(df_analysis.columns) if col.startswith('odds_')]
    odds_combination_cols = permutations(list_of_odd_cols, 2)
    
    for num, denom in odds_combination_cols:
        df_analysis[str(num)+'_divby_'+str(denom)] = df_analysis[num].div(df_analysis[denom])
    
    return df_analysis

def analyze_data_extension(df_analysis):
    df = df_analysis.copy()
    df = df.replace([np.inf, -np.inf], 9.9)
    df['normalized_samples'] = df['total_sample']/df['total_sample'].sum()
    
    ratio_of_odds_cols = [col for col in df.columns if '_divby_' in col]
    
    odd_norm_cols = []
    for col in ratio_of_odds_cols:
        df[str(col)+'_normalized'] = df[col]*df['normalized_samples']
    
    final_df = df[odd_norm_cols]
     
    mask = final_df==final_df.max(axis=0)
    indicator = final_df.where(mask,) == final_df.mask(~mask,)
    
    highlights = {}
    for i in indicator.iterrows():
        index = i[0]
        temp = i[1]
        vector = temp.iloc[np.where(temp)]
        if not vector.empty:
            highlights[index]=list(vector.index)
    
    
    
    