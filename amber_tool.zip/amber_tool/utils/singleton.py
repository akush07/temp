# -*- coding: utf-8 -*-
"""
Created on Fri Jul 16 12:24:14 2021

@author: Akush
"""




def singleton(class_):
    instances = {}
    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]
    return getinstance