# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 12:35:19 2021

@author: Akush
"""


import re
import nltk
import string
from nltk.corpus import stopwords as StopWords
from utils.configs import LoadStopwords

# nltk.download('punkt')
# nltk.download('wordnet')
# nltk.download('stopwords')
# nltk.download('vader_lexicon')

stopwords = StopWords.words('english')
stopwords = set(stopwords)
extended_stopwords = LoadStopwords()
stopwords = stopwords.union(set(extended_stopwords.stopwords))
lemmatizer = nltk.WordNetLemmatizer()
punctuation = string.punctuation


def check_extension(path:str, extension:str):
    if not (isinstance(path, str) or isinstance(extension, str)):
        raise TypeError('path or extension parameter is not in string format')
    
    path_extension = path.rsplit('.',1)[-1]
    return path_extension==extension

def add_file_extension(path:str, extension:str):
    if not check_extension(path, extension):
        path = path + '.' + extension
    return path

def remove_punctuations(text:str, filler:str='') -> str:
    return re.sub("[{}]".format(punctuation), filler, str(text))


def clean_text(text:str,
               remove_digits:bool=True,
               remove_urls:bool=True,
               remove_punctuations:bool=True,
               enable_lemmatizer:bool=True
               ):
    """
    This function cleans the text corpus.
    """
    if not isinstance(text, str):
        raise AttributeError("incorrect datatype of function parameter: text ")
    
    # Lowercase and tokenize
    text = text.lower()
    
    if remove_urls:
        text = re.sub(r'\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*', '', text, flags= re.MULTILINE) 
        text = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%|\-|\;)*\b', '', text, flags= re.MULTILINE)
        text = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%|\-|\;)*\b(\/)', '', text, flags= re.MULTILINE)
    
    if remove_punctuations:
        text = re.sub("[{}]".format(punctuation), '', text)
    
    if remove_digits:
        text = re.sub(r"[0-9]+", '', text)
       
    text_content = [word for word in text.split() if word not in stopwords and len(word)!=0]    
    if enable_lemmatizer:
        # Best to get the lemmas of each word to reduce the number of similar words
        text_content = [lemmatizer.lemmatize(word) for word in text_content]
    return ' '.join(text_content)    
    
    