# -*- coding: utf-8 -*-
"""
Created on Fri Jul 16 12:34:03 2021

@author: Akush
"""

import warnings
import logging
import os
from datetime import datetime
from utils.configs import LoadConfig

start = datetime.now()

warnings.filterwarnings("ignore", category=DeprecationWarning) 
warnings.simplefilter("ignore")
logging.captureWarnings(False)

os.environ['CONFIG_PATH'] = 'configs/config.yaml'
os.environ['STOPWORDS_PATH'] = 'configs/stopwords.yaml'

def getlogger(configpath:str= os.environ.get('CONFIG_PATH')):
    try:
        print('creating logfile..')
        
        cfg = LoadConfig(configpath)
        settings = cfg.config.get('general_settings',{})
        logspath = settings.get('logsdir', None)
        if logspath:
            os.makedirs(logspath, exist_ok=True)
            logfile = os.path.join(logspath, 'log-{}.log'.format(str(start.strftime("%d-%m-%Y %H-%M-%S"))))
            logging.basicConfig(level=logging.INFO, filename=logfile, format='%(asctime)s %(levelname)s:%(message)s')
            logger = logging.getLogger(__name__)
            return logger, str(start.strftime("%d-%m-%Y %H-%M-%S"))
        else:
            raise FileNotFoundError("unable to read logpath from config")
    except Exception as e:
        raise e
        
logger, session = getlogger()