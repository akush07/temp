# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 23:41:58 2021

@author: Akush
"""


class FileError(Exception):
    def __init__(self, message=None):
        super().__init__(message)
        
class EmptyDataFrameError(Exception):
    def __init__(self, message=None):
        super().__init__(message)

class DirCreationError(Exception):
    def __init__(self, message=None):
        super().__init__(message)
