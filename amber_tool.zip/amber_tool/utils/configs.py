# -*- coding: utf-8 -*-
"""
Created on Fri Jul 16 12:28:27 2021

@author: Akush
"""


import os
import yaml
from utils.singleton import singleton


@singleton
class LoadConfig:
    def __init__(self, configpath=os.environ.get('CONFIG_PATH', r'configs/config.yaml')):
        with open(configpath, 'r') as f:
            self.config = yaml.safe_load(f)

@singleton            
class LoadStopwords:
    def __init__(self, stopwordpath=os.environ.get('STOPWORDS_PATH', r'configs/stopwords.yaml')):
        with open(stopwordpath, 'r') as f:
            self.config = yaml.safe_load(f)
            self.stopwords = self.config.get('stopwords', [])
            
            