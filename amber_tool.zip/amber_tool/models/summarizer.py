# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 21:57:14 2021

@author: Akush
"""



import re
import nltk
import heapq
import spacy
import string
from itertools import Counter
from tqdm import tqdm
from utils.helper import stopwords

nlp = spacy.load("en_core_web_lg")
punctuation = string.punctuation


def extractive_summarizer(text:str, 
                          num_of_sentences:int=5):
    """
    This function returns the summary of long text using the extractive method for summarization
    """
    
    clean_text = re.sub(r'\[[0-9]*\]', ' ', text)
    clean_text = re.sub(r'\s+', ' ', clean_text)
    
    formatted_text = re.sub(r'[^a-zA-Z]', ' ', clean_text)
    
    sentence_list = nltk.sent_tokenize(clean_text)
    
    word_freq = {}
    
    for word in tqdm(nltk.word_tokenize(formatted_text)):
        if word not in stopwords:
            if word not in word_freq.keys():
                word_freq[word] = 1
            else:
                word_freq[word] += 1
    
    try:
        max_freq = max(word_freq.values())
    except:
        max_freq = 1
        
    for word in word_freq.keys():
        word_freq[word] = word_freq[word]/max_freq
    
    
    sentence_scores = {}
    
    for sent in tqdm(sentence_list):
        for word in nltk.word_tokenize(sent.lower()):
            if word in word_freq.keys():
                if len(sent.split()) < 30:
                    if sent not in sentence_scores.keys():
                        sentence_scores[sent] = word_freq[word]
                    else:
                        sentence_scores[sent] += word_freq[word]
    
    summary_sentences = heapq.nlargest(num_of_sentences, sentence_scores, key = sentence_scores.get)
    
    summary = ' '.join(summary_sentences)
    return summary
    
def extractive_summarization_with_spacy(text, limit):
    keyword = []
    pos_tag = ['PROPN', 'ADJ', 'NOUN', 'VERB']
    doc = nlp(text.lower())
    for token in doc:
        if(token.text in nlp.Defaults.stop_words or token.text in punctuation):
            continue
        if(token.pos_ in pos_tag):
            keyword.append(token.text)
    
    freq_word = Counter(keyword)
    max_freq = Counter(keyword).most_common(1)[0][1]
    for w in freq_word:
        freq_word[w] = (freq_word[w]/max_freq)
        
    sent_strength={}
    for sent in doc.sents:
        for word in sent:
            if word.text in freq_word.keys():
                if sent in sent_strength.keys():
                    sent_strength[sent]+=freq_word[word.text]
                else:
                    sent_strength[sent]=freq_word[word.text]
    
    summary = []
    
    sorted_x = sorted(sent_strength.items(), key=lambda kv: kv[1], reverse=True)
    
    counter = 0
    for i in range(len(sorted_x)):
        summary.append(str(sorted_x[i][0]).capitalize())

        counter += 1
        if(counter >= limit):
            break
            
    return ' '.join(summary)