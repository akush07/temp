# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 11:37:59 2021

@author: Akush
"""


import nltk
import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from utils.helper import add_file_extension, clean_text, stopwords
from sklearn.feature_extraction.text import CountVectorizer



def get_unigram_wordcloud(text:str,
                          output_filepath:str="wordcloud", 
                          file_extension:str='jpg') -> None:
    """
    This function generates unigram wordcloud on the cleaned text passed to it.
    """
    
    wordcloud = WordCloud(width = 800, height = 800,
                background_color ='white',
                stopwords = stopwords,
                min_font_size = 10).generate(text)
 
    # plot the WordCloud image                      
    plt.figure(figsize = (8, 8), facecolor = None)
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.tight_layout(pad = 0)
    #saving as jpg image
    output_filepath = add_file_extension(output_filepath, file_extension)
    wordcloud.to_file(output_filepath) 


def get_ngram_wordcloud(text:str, 
                         output_filepath:str="wordcloud", 
                         file_extension:str='jpg',
                         ngram_val:int=2) -> None:
    """
    This function generates bigram wordcloud on the cleaned text passed to it.
    """
    tokens = nltk.word_tokenize(text)  
    bigrams_list = list(nltk.bigrams(tokens))
    dictionary = [' '.join(tup) for tup in bigrams_list]   
    #Using count vectoriser to view the frequency of bigrams
    vectorizer = CountVectorizer(ngram_range=(ngram_val, ngram_val))
    
    try:
        bag_of_words = vectorizer.fit_transform(dictionary)
    except ValueError:
        raise ValueError(f"Insufficient data to transform data in ngram of {ngram_val}")
        
    sum_words = bag_of_words.sum(axis=0) 
    words_freq = [(word, sum_words[0, idx]) for word, idx in vectorizer.vocabulary_.items()]
    words_freq =sorted(words_freq, key = lambda x: x[1], reverse=True)     
    #wordcloud parameters
    words_dict = dict(words_freq)
    WC_height = 1000
    WC_width = 1500
    WC_max_words = 200
    #Generating wordcloud
    wordcloud = WordCloud(max_words=WC_max_words, height=WC_height, width=WC_width,stopwords=stopwords)    
    wordcloud.generate_from_frequencies(words_dict)
    #showing the wordcloud
    plt.title('Most frequently occurring bigrams connected by same colour and font size')
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    #saving as jpg image
    output_filepath = add_file_extension(output_filepath, file_extension)
    wordcloud.to_file(output_filepath)





if __name__=='__main__':
    df = pd.read_csv('data/raw_data/youtube/Youtube01-Psy.csv')
    text = clean_text(df.CONTENT.str.cat(sep=' '))        
    get_unigram_wordcloud(text)
    get_ngram_wordcloud(text,ngram_val=1)

    


