# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 14:10:46 2021

@author: Akush
"""


from typing import Dict
from nltk.sentiment.vader import SentimentIntensityAnalyzer



analyzer = SentimentIntensityAnalyzer()

def get_vader_sentiment(text:str) -> Dict:
    """
    This function returns the sentiment polarity and Intensity of the text
    """
    if isinstance(text, str):
        return analyzer.polarity_scores(text)
    return {'neg': 0.0, 'neu': 0.0, 'pos': 0.0, 'compound': 0.0}


if __name__=='__main__':
    text = "I was not happy then now I am happy"
    text = ''
    get_vader_sentiment(text)
    
