# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 23:25:11 2021

@author: Akush
"""


import os
import logging
import numpy as np
import pandas as pd
from tqdm import tqdm
from typing import TypeVar, List, Dict
from models.sentiment import get_vader_sentiment
from models.summarizer import extractive_summarizer
from models.wordcloud import get_ngram_wordcloud
from utils.data_func import read_data
from utils.helper import clean_text, add_file_extension, remove_punctuations
from utils.exceptions import EmptyDataFrameError, DirCreationError
from utils.configs import LoadConfig


Dataframe = TypeVar('pandas.core.dataframe.DataFrame')

logger = logging.getLogger(__name__)
stream = logging.StreamHandler()
logger.addHandler(stream)

class DataPipeline:
    def __init__(self, filepath:str=None):
        if not filepath:
            self.__filepath = None
            self.__data = pd.DataFrame()
        else:
            self.__filepath = filepath
            self.__data = read_data(filepath)
        
        self.filtered_on_question = False
        self.__cleaned_data = pd.DataFrame()
        self.__sentiment_data  = pd.DataFrame()
        self.text_col = None
        self.config = None
        self.general_settings = None
                   
    def load_data(self, filepath:str):
        self.__filepath = filepath
        self.__data = read_data(filepath)
        logger.info('raw data shape {}'.format(self.__data.shape))
        
    def load_config(self, configpath:str):
        try:
            logger.info("loading configuration..")
            cfg = LoadConfig()
            self.config = cfg.config
            self.general_settings = self.config.get('general_settings')
            self.text_cleaning = self.general_settings.get('text_cleaning',{})
            self.text_col = self.config.get('text_col')
        except Exception as e:
            logger.error(str(e))
            raise
        
    def get_raw_data(self):
        if self.__data.empty:
            raise EmptyDataFrameError("dataframe is empty")
        return self.__data
    
    def set_raw_data(self, data:Dataframe):
        if isinstance(data, pd.DataFrame):
            self.__data = data
            logger.info('raw data shape {}'.format(self.__data.shape))
        else:
            raise TypeError('not a dataframe..')
    
    def get_cleaned_data(self):
        if self.__cleaned_data.empty:
            raise EmptyDataFrameError("dataframe is empty")
        return self.__cleaned_data
    
    def set_cleaned_data(self, data:Dataframe):
        if isinstance(data, pd.DataFrame):
            self.__cleaned_data = data
            logger.info('cleaned data shape {}'.format(self.__cleaned_data.shape))
        else:
            raise TypeError('not a dataframe..')
    
    def get_sentiment_data(self):
        if self.__sentiment_data.empty:
            raise EmptyDataFrameError("dataframe is empty")
        return self.__sentiment_data
    
    def set_sentiment_data(self, data:Dataframe):
        if isinstance(data, pd.DataFrame):
            self.__sentiment_data = data
            logger.info('sentiment data shape {}'.format(self.__sentiment_data.shape))
        else:
            raise TypeError('not a dataframe..')
    
    def transform(self):
        if not self.text_col:
            raise AttributeError('could not find the text column header name, please check config..')
        
        try:                        
            logger.info("cleaning and transforming text column..")                                    
            data = self.get_raw_data().copy()
            data[self.text_col] = data[self.text_col].astype(str)
            
            filter_question_param = self.config.get('filter_questions')
            if not self.filtered_on_question:
                if filter_question_param.get('enable', False):
                    questions_vec = data.groupby(filter_question_param.get('question_col'))['response_col'].nunique()
                    questions_considered = list(questions_vec.iloc[np.where(questions_vec>10)].index)
                    data = data[data[filter_question_param.get('question_col')].isin(questions_considered)]
                    self.filtered_on_question = True                    
            self.set_raw_data(data)            
            data[self.text_col] = data[self.text_col].apply(clean_text, args=self.text_cleaning)
            self.set_cleaned_data(data.copy())
            del data
        except Exception as e:
            logger.error(e)
            raise

                
class TextModel(DataPipeline):
    def __init__(self, session:str, **kwargs):
        super(TextModel, self).__init__(**kwargs)
        self.session = session
        self.output_dir = None
        
    def set_output_dir(self, output_dir_path:str=None):
        if output_dir_path:
            self.output_dir = output_dir_path
            os.makedirs(self.output_dir, exist_ok=True)
        elif self.general_settings:            
            self.output_dir = self.general_settings.get('outputdir')
            os.makedirs(self.output_dir, exist_ok=True)
        else:
            logger.error('output directory path not provided, loading default output directory..')
            self.output_dir = 'outputs'
            os.makedirs(self.output_dir, exist_ok=True)
            
    
    def get_sentiment(self, save_sentiment_file=False):
        data = self.get_raw_data().copy()        
        logger.info("starting sentiment analyzer..")
        for index in tqdm(data.index):
            sentiment_output = get_vader_sentiment(data.loc[index, self.text_col]) 
            data.at[index,'negative'] =  sentiment_output.get('neg', 0.0)
            data.at[index,'positive'] =  sentiment_output.get('pos', 0.0)
            data.at[index,'neutral'] =  sentiment_output.get('neu', 0.0)
            data.at[index,'final sentiment score'] =  sentiment_output.get('compound', 0.0)
        self.set_sentiment_data(data.copy())
        logger.info("completed sentiment analysis..")
        if save_sentiment_file:
            logger.info("saving sentiment analysis output..")
            output_dir = os.path.join(self.output_dir, 'sentiment') 
            os.makedirs(output_dir, exist_ok=True)
            data.to_csv(os.path.join(output_dir, add_file_extension('data with sentiment','csv')))  
            logger.info("sentiment analysis output successfully saved..")
        return self
    
    def get_wordcloud(self, grouping_col:List[str]=None):
        data = self.get_cleaned_data()
        data = data[data[self.text_col].notna()]
        output_dir = os.path.join(self.output_dir, 'wordcloud')
        os.makedirs(output_dir, exist_ok=True)
        logger.info("starting wordcloud generation..")
        if not grouping_col:
            get_ngram_wordcloud(data[self.text_col].str.cat(sep=' '),
                                output_filepath=os.path.join(output_dir, 'overall_wordcloud'))
            logger.info("completed wordcloud generation..")
        else:
            for group in data.groupby(grouping_col)[self.text_col]:
                level_name = group[0]
                text_vector = group[1]
                try:
                    get_ngram_wordcloud(text_vector.str.cat(sep=' '), 
                                        output_filepath=os.path.join(output_dir, remove_punctuations(level_name)))
                    logger.info("completed wordcloud generation for level {}..".format(level_name))
                except ValueError:
                    logger.warning(f'skipping: unable to process wordcloud for {level_name}')
        del data
        logger.info("completed wordcloud generation..")
        return self
                    
    
    def get_summaries(self, grouping_col:List[str]=None) -> Dict:
        data = self.get_raw_data()
        data = data[data[self.text_col].notna()]
        summaries = {}
        logger.info("starting summary generation..")
        if not grouping_col:
            summaries['summary'] = extractive_summarizer(data[self.text_col].str.cat(sep=' '))
            logger.info("completed summary generation..")
        else:
            for group in data.groupby(grouping_col)[self.text_col]:
                level_name = group[0]
                text_vector = group[1]
                try:
                    summaries[str(level_name)] = extractive_summarizer(text_vector.str.cat(sep=' '))
                    logger.info("completed summary generation for level{}..".format(level_name))
                except ValueError:
                    logger.warning(f'skipping: unable to process summaries for {level_name}')
        del data
        logger.info("completed summary generation..")
        output_dir = os.path.join(self.output_dir, 'summaries')
        os.makedirs(output_dir, exist_ok=True)
                
        with open(os.path.join(output_dir, add_file_extension('summaries', 'txt')), 'w+') as f:
            logger.info("saving summary data into file..")
            text = ''
            for level, summary in summaries.items():                
                text = text + str("for Cohort: " + level + '\n' + 'summary:' + '\n' + summary + '\n')
                text = text.encode('utf-8').decode('ascii', 'ignore')
            f.writelines(text)
            logger.info("completed saving summary data..")
        return self
                    
            
            